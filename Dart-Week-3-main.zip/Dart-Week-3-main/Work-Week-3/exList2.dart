void main(List<String> args) {
  var flower = ['rose', 'sunflower', 'poppy'];

  for (var i = 0; i < flower.length; i++) {
    print(flower);
  }
}
